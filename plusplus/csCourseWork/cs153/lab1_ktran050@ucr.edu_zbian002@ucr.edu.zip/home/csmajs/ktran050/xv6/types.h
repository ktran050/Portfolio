typedef unsigned int   uint;
typedef unsigned short ushort;
typedef unsigned char  uchar;
typedef uint pde_t;
typedef int bool;
#define NULL 0
#define false 0
#define true 1
